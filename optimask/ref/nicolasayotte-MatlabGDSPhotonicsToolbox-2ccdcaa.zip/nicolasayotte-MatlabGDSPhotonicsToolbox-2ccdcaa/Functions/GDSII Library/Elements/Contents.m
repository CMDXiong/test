% Functions that Return gds_element Objects 
% =========================================
%
% gdsii_ptext -  renders a text string with boundary elements.
% gdsii_arc   -  creates arcs, circles, and circle segments.
%
% Ulf Griesmann, NIST, 2008 - 2013
% -------------------------------------------------------

