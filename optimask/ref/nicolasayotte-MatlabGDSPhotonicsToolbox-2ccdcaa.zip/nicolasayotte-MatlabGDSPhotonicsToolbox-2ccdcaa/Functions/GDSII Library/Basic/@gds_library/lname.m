function ln = lname(glib);
%function ln = lname(glib);
%
% return the library name of a gds_library object
%
% ln :   the new name of the library
%

ln = glib.lname;

return
