function str = cleargds(str)

% This function deletes existing gds data in str.
% SF, May 2 2007

str.gds = [];