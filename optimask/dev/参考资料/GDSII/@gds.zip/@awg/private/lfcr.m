function lf_cr=lfcr()

%output the cartridge return and line shift characters

lf_cr=[13,10];
lf_cr=setstr(lf_cr);
