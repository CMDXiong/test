function lib = rename(lib,name)

% RENAME(LIB,NAME) renames the LIB to NAME.

lib.name = name;
lib.libname = name;
