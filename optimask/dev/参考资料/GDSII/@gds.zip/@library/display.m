function  display(lib)

disp(['Library ' lib.name '; ' num2str(lib.n) ' polygons.'])