function lib = rename(lib,name)

% RENAME(LIB,NAME) renames the library LIB to NAME.

% Attila Mekis, May 12, 2003

lib.name = name;
lib.libname = name;
