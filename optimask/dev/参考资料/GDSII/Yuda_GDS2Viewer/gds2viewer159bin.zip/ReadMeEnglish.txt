Outline
	GDSII Viewer is free software runs on WindowsNT/2000/XP,
	lets you see your IC layout (GDSII-Stream format data).

Feature
        Easy operation, fast reading, fast rendering and
        print capability with real hatch.

Misc.
	Refer to help file (.hlp) for installation, license
        information and release note as well as how to
        operate.

Misc.2
	This software was compiled by Microsoft Visual C++ 6.0.
	You also need Microsoft Platform SDK (Windows Core) which
	you can download from Microsoft's web page without fee.
	Note that I don't have .NET and have no idea whether you
	can compile using .NET.

Authour
	yuda @ akina.ne.jp (English or Japanese:prefer)

Distribution site
	http://www.vector.co.jp/soft/dl/winnt/business/se243021.html
	Source code is also available.