#if !defined(AFX_STDAFX_H__16A0FA80_C95F_4589_821A_6C777F645BFF__INCLUDED_)
#define AFX_STDAFX_H__16A0FA80_C95F_4589_821A_6C777F645BFF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define VC_EXTRALEAN
#include <afxwin.h>
#include <afxext.h>
#include <afxdisp.h>
#include <afxdtctl.h>
#include <afxole.h>

#include <gdiplus.h>
using namespace Gdiplus;

#include <math.h>
#include <float.h>

#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>
#endif // _AFX_NO_AFXCMN_SUPPORT
#include <afxpriv.h>

#define NEWLINE "\r\n"

//{{AFX_INSERT_LOCATION}}

#endif // !defined(AFX_STDAFX_H__16A0FA80_C95F_4589_821A_6C777F645BFF__INCLUDED_)
